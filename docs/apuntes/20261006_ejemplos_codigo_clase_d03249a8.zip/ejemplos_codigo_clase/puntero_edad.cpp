// https://www.w3schools.com/c/tryc.php?filename=demo_pointers

#include <stdio.h>

int main() {
  int myAge = 43;  // El entero de la variable (guarda el valor de edad que queremos)
  int *ptr = &myAge;  // El puntero que guarda la dirección de memoria (es como anotar la dirección de la vivienda de una persona). OJOOO! se ponen * y &

  // Imprimimos el valor de edad (debería dar 43)
  printf("El valor dentro de edad es %d\n", myAge);

  // Imprimimos la dirección (debería devolver una dirección larga en hexadecimal)
  printf("La dirección de memoria que almacena edad es %p\n", &myAge);

  // Imprimos el valor que almacena el puntero (debería ser la dirección de memoria de myAge)
  printf("El puntero que guarda o sabe dónde está la variable edad en memoria contiene la dirección %p\n", ptr);

  // Imprimimos la dirección de memoria del puntero (debería ser una dirección distinta a myAge)
  printf("La dirección de memoria del puntero es %p\n", &ptr);

  // En resumen, el valor que almacena el puntero es la dirección de memoria de la variable myAge (en esa dirección se guarda el valor 43). Podemos comprobarlo:
  if (&myAge == ptr){
  	printf("Son iguales\n");
  }

  // Qué pasa si se quita el & de myAge al declarar el puntero? int *ptr = myAge

  return 0;
}