#include <stdio.h>

#define FILAS 3       // Tamaño útil sin bordes
#define COLUMNAS 3

int main() {
    // Declaramos matriz orlada de (FILAS+2)x(COLUMNAS+2), inicializada a 0
    int matriz[FILAS + 2][COLUMNAS + 2] = {0};

    // Rellenamos solo la parte útil (sin bordes) con algunos valores
    // Imaginamos que estamos procesando una "zona activa"
    matriz[1][1] = 0;
    matriz[1][2] = 1;
    matriz[1][3] = 0;

    matriz[2][1] = 1;
    matriz[2][2] = 1;
    matriz[2][3] = 0;

    matriz[3][1] = 0;
    matriz[3][2] = 0;
    matriz[3][3] = 1;

    // Mostramos la matriz útil original
    printf("Matriz original:\n");
    for (int i = 1; i <= FILAS; i++) {
        for (int j = 1; j <= COLUMNAS; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    // Ahora contamos los vecinos con valor 1 para cada celda de la zona útil
    printf("\nVecinos con valor 1 por celda:\n");
    for (int i = 1; i <= FILAS; i++) {
        for (int j = 1; j <= COLUMNAS; j++) {
            int vecinos = 0;

            // Recorremos las 8 posiciones vecinas (i-1 a i+1, j-1 a j+1)
            for (int di = -1; di <= 1; di++) {
                for (int dj = -1; dj <= 1; dj++) {
                    // Evitamos contar la celda central
                    if (di != 0 || dj != 0) {
                        vecinos += matriz[i + di][j + dj];
                    }
                }
            }

            // Imprimimos cuántos vecinos con valor 1 tiene esta celda
            printf("%d ", vecinos);
        }
        printf("\n");
    }

    return 0;
}
