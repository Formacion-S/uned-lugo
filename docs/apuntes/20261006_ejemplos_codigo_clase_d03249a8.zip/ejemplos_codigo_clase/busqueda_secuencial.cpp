#include <stdio.h>

// El programa pide un número al usuario y busca dicho número dentro de un vector
// recorriéndolo secuencialmente. La búsqueda secuencial es la técnica más básica
// para buscar en un array: revisar uno a uno hasta encontrarlo o llegar al final.

int main() {
    // Declaramos un vector de 5 elementos enteros.
    int v[5] = {10, 20, 30, 40, 50};

    // Variable donde guardamos el número a buscar
    int x;

    // Variable de control: indica si el número fue encontrado (1) o no (0)
    int encontrado = 0;

    // Mostramos primero al usuario el contenido del vector
    printf("Contenido del vector: ");
    for(int i = 0; i < 5; i++) {
        printf("%d ", v[i]); // Imprimimos cada elemento separado por espacios
    }
    printf("\n"); // Salto de línea tras mostrar el vector

    // Pedimos al usuario que introduzca el número a buscar
    printf("Introduce el número a buscar: ");
    scanf("%d", &x); // Guardamos la entrada del usuario en la variable x

    // Recorremos el vector desde el primer al último elemento
    for(int i = 0; i < 5; i++) {
        // Comparamos cada elemento con el número buscado
        if(v[i] == x) {
            encontrado = 1; // Marcamos que lo encontramos
            break;          // Salimos del bucle anticipadamente
        }
    }

    // Mostramos el resultado según se haya encontrado o no
    if(encontrado)
        printf("El número está en el vector.\n");
    elseq
        printf("No se encontró el número.\n");

    // Indicamos fin correcto del programa
    return 0;
}
