#include <stdio.h> 

int main() {
    // Declaramos una matriz de 3 filas y 3 columnas. 
    // La inicializamos directamente con valores para simplificar el ejemplo.
    int matriz[3][3] = {
        {1, 2, 3},  // Primera fila
        {4, 5, 6},  // Segunda fila
        {7, 8, 9}   // Tercera fila
    };

    // Mensaje informativo al usuario indicando que comienza el recorrido
    printf("Recorriendo matriz:\n");

    // Bucle externo: recorre las filas de la matriz. 
    // i representa el índice de la fila actual.
    for(int i = 0; i < 3; i++) {
        
        // Bucle interno: recorre las columnas de la fila actual.
        // j representa el índice de la columna actual.
        for(int j = 0; j < 3; j++) {
            
            // Imprime el elemento en la posición [i][j] seguido de un espacio.
            // Esto permite mostrar todos los elementos de una fila en una misma línea.
            printf("%d ", matriz[i][j]);
        }

        // Una vez impresos todos los elementos de una fila, 
        // se imprime un salto de línea para pasar a la siguiente fila.
        printf("\n");
    }

    // Retorna 0 para indicar que el programa ha finalizado correctamente.
    return 0;
}
