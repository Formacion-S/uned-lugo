#include <stdio.h>

int main() {
    int matriz[3][4]; // Matriz de 3 filas y 4 columnas

    // Inicialización de la matriz con valores
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 4; j++) {
            matriz[i][j] = i + j;
        }
    }

    // Mostrar los valores de la matriz
    printf("Contenido de la matriz:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 4; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
