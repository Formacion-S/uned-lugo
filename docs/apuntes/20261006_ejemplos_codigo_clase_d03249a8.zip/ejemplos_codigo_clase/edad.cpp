#include <stdio.h>

int main() {
  int myAge = 43;
  
  printf("El valor es %d\n", myAge);
  printf("Está almacenado en %p\n", &myAge);
  return 0;
}