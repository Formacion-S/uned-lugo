#include <stdio.h>
#include <math.h>

int main (){

  int anho= 2220;
  int mes= 1;
  int dia= 1;
  int a=0;
  int b=0;
  int d=0;

  if(mes<=2){
    mes = mes +10;
    anho=anho-1;
  }else{
    mes = mes-2;
  }
  a = anho % 100;
  b = floor(anho /100);
  d = 700 + floor((mes*26-2)/10) + dia + a + floor (a/4) + floor (b/4) - (b*2);

  d = d%7;

  printf("Valor: %d",d);

  return 0;
}
