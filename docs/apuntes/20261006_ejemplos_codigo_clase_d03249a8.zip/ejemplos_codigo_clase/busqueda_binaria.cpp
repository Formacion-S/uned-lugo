#include <stdio.h>

int main() {
    // Vector de enteros ordenado de menor a mayor.
    // Este orden es obligatorio para que la búsqueda binaria funcione.
    int v[] = {10, 20, 30, 40, 50};

    // Variables de control
    int x;               // Número que vamos a buscar
    int inf = 0;         // Índice inferior del rango de búsqueda
    int sup = 4;         // Índice superior (última posición válida del vector)
    int mid;             // Índice del punto medio del rango actual
    int encontrado = 0;  // Bandera que indica si se ha encontrado el número

    // Mostramos el contenido del vector
    printf("Contenido del vector: ");
    for (int i = 0; i <= sup; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");

    // Solicitamos al usuario el número que desea buscar
    printf("Introduce el número a buscar: ");
    scanf("%d", &x);

    // Algoritmo de búsqueda binaria:
    // mientras el rango no se haya agotado y el número no se haya encontrado
    while (inf <= sup && !encontrado) {
        // Calculamos el índice del punto medio
        mid = (inf + sup) / 2;

        // Comparamos el valor en la posición 'mid' con el valor buscado
        if (v[mid] == x) {
            // Si son iguales, lo encontramos
            encontrado = 1;
        } else if (v[mid] < x) {
            // Si el del medio es menor, el número debe estar a la derecha
            inf = mid + 1;
        } else {
            // Si el del medio es mayor, buscamos en la parte izquierda
            sup = mid - 1;
        }
    }

    // Informamos al usuario del resultado
    if(encontrado)
        printf("Elemento encontrado en el vector.\n");
    else
        printf("No se encontró el elemento.\n");

    return 0; // Fin del programa
}