#include <stdio.h>

// Usamos una unión para representar un número que puede ser entero o decimal, pero no ambos a la vez
typedef union {
    int entero;
    float decimal;
} TipoNumero;

// Añadimos un campo 'tipo' para saber qué tipo está en uso
typedef struct {
    char tipo; // 'e' para entero, 'd' para decimal
    TipoNumero valor;
} NumeroFlexible;

int main() {
    NumeroFlexible num;

    // Pedimos al usuario que elija el tipo de número que quiere introducir
    printf("Introduce el tipo de número ('e' para entero, 'd' para decimal): ");
    scanf(" %c", &num.tipo);  // Espacio antes de %c para evitar problemas con el buffer

    if (num.tipo == 'e') {
        printf("Introduce un número entero: ");
        scanf("%d", &num.valor.entero);
        printf("El número entero es: %d\n", num.valor.entero);
    } else if (num.tipo == 'd') {
        printf("Introduce un número decimal: ");
        scanf("%f", &num.valor.decimal);
        printf("El número decimal es: %.2f\n", num.valor.decimal);
    } else {
        printf("Tipo no válido.\n");
    }

    return 0;
}
