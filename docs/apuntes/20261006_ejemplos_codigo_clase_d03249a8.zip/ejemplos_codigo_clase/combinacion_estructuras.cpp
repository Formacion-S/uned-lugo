#include <stdio.h>
#include <string.h>

// Creamos la estructura para representar una persona con nombre y edad
typedef struct {
    char nombre[20];
    int edad;
} Persona;

// Creamos una tabla de personas como un array de estructuras con un campo adicional 'total'
typedef struct {
    Persona personas[100];
    int total;
} TablaPersonas;

int main() {
    TablaPersonas tabla;
    tabla.total = 0;  // Inicializamos el contador

    int n;
    printf("¿Cuántas personas quieres introducir? ");
    scanf("%d", &n);

    // Pedimos los datos de cada persona
    for (int i = 0; i < n; i++) {
        printf("Persona %d\n", i + 1);
        printf("Nombre: ");
        scanf("%s", tabla.personas[i].nombre);  // No usamos espacios en nombres por simplicidad
        printf("Edad: ");
        scanf("%d", &tabla.personas[i].edad);
        tabla.total++;
    }

    // Mostramos todas las personas introducidas
    printf("\nLista de personas:\n");
    for (int i = 0; i < tabla.total; i++) {
        printf("Nombre: %s, Edad: %d\n", tabla.personas[i].nombre, tabla.personas[i].edad);
    }

    return 0;
}
