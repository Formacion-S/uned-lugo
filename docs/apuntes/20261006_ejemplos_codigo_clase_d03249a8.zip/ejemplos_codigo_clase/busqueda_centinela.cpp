#include <stdio.h>

int main() {
    // Declaramos un vector con espacio para 6 elementos.
    // Los 5 primeros son valores válidos; el último se usará como centinela.
    int v[6] = {10, 20, 30, 40, 50}; // el último valor se sobrescribirá

    int x;     // Número a buscar
    int i = 0; // Índice para recorrer el vector

    // Mostramos el contenido actual del vector (sin el centinela aún)
    printf("Contenido del vector: ");
    for (int j = 0; j < 5; j++) {
        printf("%d ", v[j]);
    }
    printf("\n");

    // Pedimos al usuario que introduzca el número a buscar
    printf("Introduce el número a buscar: ");
    scanf("%d", &x);

    // Insertamos el número a buscar en la última posición del vector (posición 5)
    // Esto es el "centinela", que garantiza que el bucle terminará siempre.
    v[5] = x;

    // Iniciamos el bucle de búsqueda.
    // Ya no necesitamos comprobar si i < tamaño, porque el centinela garantiza que
    // eventualmente se encontrará el valor (aunque sea en la última posición).
    while (v[i] != x) {
        i++; // Avanzamos al siguiente elemento
    }

    // Comprobamos si el índice donde encontramos el valor está dentro del rango real.
    // Si i < 5, el número estaba en el vector original.
    // Si i == 5, solo lo encontró porque era el centinela, no estaba realmente.
    if (i < 5)
        printf("Elemento encontrado en la posición %d.\n", i);
    else
        printf("Elemento no está en el vector.\n");

    return 0; // Fin del programa
}
