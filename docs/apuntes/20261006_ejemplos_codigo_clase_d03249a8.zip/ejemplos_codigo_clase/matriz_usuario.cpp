#include <stdio.h>

int main() {
    int filas, columnas;

    // Pedimos al usuario las dimensiones de la matriz porque en este ejemplo la matriz se construye dinámicamente en función del tamaño introducido
    printf("Introduce el número de filas: ");
    scanf("%d", &filas);

    printf("Introduce el número de columnas: ");
    scanf("%d", &columnas);

    // Declaramos una matriz de tamaño fijo (1000x1000) porque en C no podemos declarar arrays con tamaño dinámico puro sin usar memoria dinámica
    // Este límite evita errores si el usuario introduce un tamaño demasiado grande
    int matriz[1000][1000];

    // Usamos dos bucles anidados para recorrer la matriz por filas y columnas
    // Esto es necesario porque una matriz bidimensional requiere recorrer ambos ejes para acceder a cada elemento
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            // Pedimos al usuario un valor para cada celda de la matriz
            // Porque queremos que el contenido de la matriz sea definido manualmente y no por defecto
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    // Imprimimos la matriz para que el usuario pueda verificar visualmente si los datos se han introducido correctamente
    // Este paso también es útil para depurar y comprobar el funcionamiento del programa
    printf("La matriz introducida es:\n");
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            // Imprimimos con \t (tabulador) para que los elementos queden alineados como una tabla
            printf("%d\t", matriz[i][j]);
        }
        // Al final de cada fila, añadimos un salto de línea para estructurar la salida como una matriz
        printf("\n");
    }

    // Devolvemos 0 porque es la forma estándar de indicar que el programa terminó sin errores
    return 0;
}
