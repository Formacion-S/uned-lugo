#include <stdio.h>

int main() {
    // ------------------------------
    // DETECCIÓN DEL TAMAÑO DE UN VECTOR
    // ------------------------------

    // Declaramos un vector de 5 enteros
    int vector[] = {10, 20, 30, 40, 50};

    // Calculamos el número de elementos del vector:
    // sizeof(vector) devuelve el tamaño total en bytes del array
    // sizeof(vector[0]) devuelve el tamaño de un solo elemento
    // Al dividirlos obtenemos la cantidad de elementos
    int tam_vector = sizeof(vector) / sizeof(vector[0]);

    // Mostramos el contenido del vector y su tamaño
    printf("Contenido del vector: ");
    for(int i = 0; i < tam_vector; i++) {
        printf("%d ", vector[i]);
    }
    printf("\nTamaño del vector: %d elementos\n\n", tam_vector);


    // ------------------------------
    // DETECCIÓN DEL TAMAÑO DE UNA MATRIZ BIDIMENSIONAL
    // ------------------------------

    // Declaramos una matriz de 3 filas y 4 columnas
    int matriz[3][4] = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12}
    };

    // Total de elementos: tamaño total dividido entre tamaño de un entero
    int total_elementos = sizeof(matriz) / sizeof(int);

    // Número de filas: tamaño total dividido entre el tamaño de una fila completa
    int filas = sizeof(matriz) / sizeof(matriz[0]);

    // Número de columnas: tamaño de una fila dividido entre el tamaño de un elemento
    int columnas = sizeof(matriz[0]) / sizeof(matriz[0][0]);

    // Mostramos el tamaño calculado
    printf("Tamaño de la matriz: %d filas x %d columnas\n", filas, columnas);
    printf("Total de elementos: %d\n", total_elementos);

    // Mostramos el contenido de la matriz
    printf("Contenido de la matriz:\n");
    for(int i = 0; i < filas; i++) {
        for(int j = 0; j < columnas; j++) {
            printf("%2d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0; // Fin del programa
}
