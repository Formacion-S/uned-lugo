#include <stdio.h>

// Esta función inicializa todos los elementos de un vector a 0
// Se usa porque no sabemos de antemano el tamaño del vector, así que lo generalizamos
void inicializar_vector(int v[], int tam) {
    for (int i = 0; i < tam; i++) {
        v[i] = 0;  // Establecemos cada elemento en 0 para evitar datos aleatorios
    }
}

int main() {
    int tam;

    // Pedimos al usuario el tamaño del vector porque queremos que sea configurable
    printf("Introduce el tamaño del vector: ");
    scanf("%d", &tam);

    int vector[100];  // Usamos un tamaño máximo por simplicidad. No usamos memoria dinámica aquí.

    // Llamamos a la función para inicializar el vector
    inicializar_vector(vector, tam);

    // Mostramos el contenido del vector para verificar que está todo a 0
    printf("Contenido del vector:\n");
    for (int i = 0; i < tam; i++) {
        printf("%d ", vector[i]);
    }

    printf("\n");
    return 0;
}
