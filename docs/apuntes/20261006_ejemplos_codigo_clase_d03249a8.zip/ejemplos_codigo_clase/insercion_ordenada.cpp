#include <stdio.h> // Librería estándar para entrada/salida (printf, scanf)

int main() {
    // Vector con 5 elementos ordenados ascendentemente.
    // Dejamos una posición extra (espacio para 6) para insertar uno más.
    int v[6] = {10, 20, 30, 40, 50};

    // 'n' indica cuántos elementos válidos hay actualmente en el vector
    int n = 5;

    // Variable para almacenar el nuevo valor que el usuario quiere insertar
    int x;

    // 'pos' nos dirá en qué posición hay que insertar el nuevo valor
    int pos;

    // Mostramos el vector actual
    printf("Contenido actual del vector: ");
    for(int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");

    // Pedimos al usuario el valor que quiere insertar
    printf("Introduce el valor a insertar (se mantendrá el orden): ");
    scanf("%d", &x);

    printf("Indica en qué posicioón insertar: ");
    scanf("%d", &pos);

    // Buscamos la posición donde debemos insertar el valor
    // Avanzamos mientras los valores del vector sean menores que x
    while (pos < n && v[pos] < x) {
        pos++;
    }

    // Una vez determinada la posición,
    // desplazamos todos los elementos hacia la derecha para hacer sitio
    for (int i = n; i > pos; i--) {
        v[i] = v[i - 1];  // Copiamos cada elemento una posición a la derecha
    }

    // Insertamos el nuevo valor en la posición encontrada
    v[pos] = x;

    // Incrementamos el número de elementos válidos del vector
    n++;

    // Mostramos el vector después de la inserción
    printf("Vector tras insertar el valor:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");

    // Fin del programa
    return 0;
}
